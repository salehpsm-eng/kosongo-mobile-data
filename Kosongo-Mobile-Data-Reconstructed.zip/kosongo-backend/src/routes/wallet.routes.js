const r = require('express').Router();
const auth = require('../middleware/auth');
const idem = require('../middleware/idempotency');
const c = require('../controllers/wallet.controller');
r.get('/', auth, c.balance);
r.get('/transactions', auth, c.transactions);
r.post('/fund', auth, idem, c.fund);
module.exports = r;
