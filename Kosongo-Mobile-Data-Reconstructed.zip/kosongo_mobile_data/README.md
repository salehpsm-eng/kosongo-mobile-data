# Kosongo Mobile Data — Flutter starter
Customer app starter reconstructed from the chat.

Features planned: MTN/Airtel/Glo/9mobile data, airtime, cable TV, electricity, wallet funding, transactions, referrals, notifications, support, beneficiaries and receipts.

Run with a production/backend URL using `--dart-define=API_BASE_URL=https://your-domain/api`.
