export const metadata={title:'Kosongo Admin',description:'Kosongo Mobile Data administration'};
export default function Layout({children}){return <html><body style={{fontFamily:'Arial',margin:0}}>{children}</body></html>}
