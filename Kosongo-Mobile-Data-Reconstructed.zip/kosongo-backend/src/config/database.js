const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function runSerializable(fn) {
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      return await prisma.$transaction(fn, { isolationLevel: 'Serializable' });
    } catch (error) {
      if (error.code === 'P2034' && attempt < 2) continue;
      throw error;
    }
  }
}

// Export the Prisma client directly for existing route/controller imports,
// while also exposing named properties for services that destructure them.
prisma.prisma = prisma;
prisma.runSerializable = runSerializable;

module.exports = prisma;
