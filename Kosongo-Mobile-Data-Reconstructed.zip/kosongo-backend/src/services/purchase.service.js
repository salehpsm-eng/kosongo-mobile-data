const { Prisma } = require('@prisma/client');
const prisma = require('../config/database');
const { runSerializable, debitWalletInTransaction, creditWalletInTransaction } = require('./wallet.service');
const { assertTransition, providerState } = require('./status.service');
const { createRequestId } = require('../utils/request-id');

async function existing(model, key){ return prisma[model].findUnique({where:{idempotencyKey:key}}); }
async function mark(model,id,to,providerReference){ return prisma.$transaction(async tx=>{ const row=await tx[model].findUnique({where:{id}}); if(!row)return null; assertTransition(row.status,to); return tx[model].update({where:{id},data:{status:to,providerReference:providerReference||row.providerReference}}); }); }
async function refund(model,id,source){ return runSerializable(async tx=>{ const row=await tx[model].findUnique({where:{id}}); if(!row)return null; if(row.status==='REFUNDED')return row; if(row.status!=='FAILED') assertTransition(row.status,'FAILED'); if(row.status==='PENDING') await tx[model].update({where:{id},data:{status:'FAILED'}}); await creditWalletInTransaction(tx,{userId:row.userId,amount:row.amount,sourceType:source,reference:`REFUND-${row.requestId}`,description:`Refund for ${row.requestId}`}); return tx[model].update({where:{id:row.id},data:{status:'REFUNDED'}}); }); }
async function createPurchase({model, idempotencyKey, userId, amount, createData, sourceType, refundSourceType, providerCall}){
  const old=await existing(model,idempotencyKey); if(old)return {order:old,created:false};
  const requestId=createRequestId();
  let order=await runSerializable(async tx=>{ const race=await tx[model].findUnique({where:{idempotencyKey}}); if(race)return race; const created=await tx[model].create({data:{...createData,requestId,idempotencyKey,status:'PENDING'}}); await debitWalletInTransaction(tx,{userId,amount,sourceType,reference:requestId,description:`${model} purchase`}); return created; });
  if(!order)return null;
  if(!order.requestId) return {order,created:false};
  try { const r=await providerCall(requestId); const state=providerState(r?.content?.transactions?.status||r?.content?.transaction?.status||r?.status); if(state==='SUCCESSFUL') order=await mark(model,order.id,'SUCCESSFUL',r?.content?.transactions?.transactionId||r?.content?.transactions?.reference); else if(state==='FAILED') order=await refund(model,order.id,refundSourceType); }
  catch(e){ /* timeout/unknown remains pending for requery */ }
  return {order,created:true};
}
module.exports={createPurchase,mark,refund,providerState};
