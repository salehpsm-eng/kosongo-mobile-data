const axios=require('axios');const env=require('../config/env');const base=env.VT_PASS_BASE_URL||'https://sandbox.vtpass.com/api';
async function post(path,data){const r=await axios.post(`${base}${path}`,data,{headers:{'api-key':env.VT_PASS_API_KEY,'secret-key':env.VT_PASS_SECRET_KEY,'Content-Type':'application/json'},timeout:30000});return r.data;}
async function get(path){const r=await axios.get(`${base}${path}`,{headers:{'api-key':env.VT_PASS_API_KEY,'public-key':env.VT_PASS_PUBLIC_KEY},timeout:30000});return r.data;}
module.exports={
 getDataServices:()=>get('/services?identifier=data'),getDataVariations:(serviceID)=>get(`/service-variations?serviceID=${encodeURIComponent(serviceID)}`),
 purchaseData:(data)=>post('/pay',data),purchaseAirtime:(data)=>post('/pay',data),subscribeCable:(data)=>post('/pay',data),purchaseElectricity:(data)=>post('/pay',data),
 verifyCable:(data)=>post('/merchant-verify',data),verifyMeter:(data)=>post('/merchant-verify',data),requery:(request_id)=>post('/requery',{request_id})
};
