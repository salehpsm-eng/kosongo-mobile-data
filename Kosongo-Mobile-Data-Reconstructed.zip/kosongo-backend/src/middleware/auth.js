const jwt=require('jsonwebtoken');
function auth(req,res,next){const h=req.headers.authorization||'';const token=h.startsWith('Bearer ')?h.slice(7):null;if(!token)return res.status(401).json({success:false,message:'Unauthorized'});try{req.user=jwt.verify(token,process.env.JWT_SECRET);next();}catch{return res.status(401).json({success:false,message:'Invalid token'});}}
function admin(req,res,next){if(!req.user)return res.status(401).json({success:false,message:'Unauthorized'});if(!['ADMIN','SUPER_ADMIN'].includes(req.user.role))return res.status(403).json({success:false,message:'Forbidden'});next();}
function superAdmin(req,res,next){if(req.user?.role!=='SUPER_ADMIN')return res.status(403).json({success:false,message:'Super admin only'});next();}
module.exports={auth,admin,superAdmin};
