# Kosongo Mobile Data — Backend starter
Node.js + Express + PostgreSQL + Prisma backend blueprint based on the development chat.

## Setup
1. Copy `.env.example` to `.env` and fill secrets.
2. `npm install`
3. `npx prisma format`
4. `npx prisma validate`
5. `npx prisma generate`
6. `npx prisma migrate dev --name init`
7. `npm start`

## Important
- This ZIP is a reconstructed starter from the chat, not a previously existing ZIP.
- Provider purchase services, auth controllers, full routes, requery worker, tests, and Flutter UI still need implementation against the exact project requirements.
- Never put VTpass/Paystack secret keys in Flutter.
