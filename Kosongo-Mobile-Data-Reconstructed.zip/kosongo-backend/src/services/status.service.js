const transitions={PENDING:['SUCCESSFUL','FAILED'],FAILED:['REFUNDED'],SUCCESSFUL:[],REFUNDED:[]};
function canTransition(from,to){return from===to||(transitions[from]||[]).includes(to)}
function assertTransition(from,to){if(!canTransition(from,to))throw new Error(`Invalid transaction status transition: ${from} → ${to}`)}
function providerState(v){const s=String(v||'').trim().toLowerCase();if(['delivered','successful','success'].includes(s))return 'SUCCESSFUL';if(['failed','failure','reversed','reversal','cancelled','canceled'].includes(s))return 'FAILED';return 'PENDING'}
module.exports={transitions,canTransition,assertTransition,providerState};
