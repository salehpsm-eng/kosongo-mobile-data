const prisma=require('../config/database'); const vtpass=require('../providers/vtpass.provider'); const {createPurchase}=require('./purchase.service');
async function purchase({userId,network,phone,amount,idempotencyKey}){
 const result=await createPurchase({model:'airtimeOrder',idempotencyKey,userId,amount,sourceType:'AIRTIME_PURCHASE',refundSourceType:'AIRTIME_REFUND',createData:{userId,network,phone,amount,providerAmount:amount,profit:0},providerCall:(requestId)=>vtpass.purchaseAirtime({request_id:requestId,serviceID:{MTN:'mtn-airtime',AIRTEL:'airtel-airtime',GLO:'glo-airtime',NINEMOBILE:'etisalat-airtime'}[network],amount:Number(amount),phone})}); return result; }
module.exports={purchase};
