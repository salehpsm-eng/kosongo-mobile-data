import 'package:uuid/uuid.dart';
class Idempotency { static const _u=Uuid(); static String data()=> 'KMD-DATA-${_u.v4()}'; static String airtime()=> 'KMD-AIRTIME-${_u.v4()}'; static String cable()=> 'KMD-CABLE-${_u.v4()}'; static String electricity()=> 'KMD-ELECTRICITY-${_u.v4()}'; static String wallet()=> 'KMD-WALLET-${_u.v4()}'; }
