const prisma=require('../config/database');
exports.dataNetworks=async(req,res,next)=>{try{res.json({success:true,data:['MTN','AIRTEL','GLO','NINEMOBILE']})}catch(e){next(e)}};
exports.dataPlans=async(req,res,next)=>{try{const where={isActive:true};if(req.query.network)where.network=req.query.network;res.json({success:true,data:await prisma.dataPlan.findMany({where,orderBy:{sellingPrice:'asc'}})})}catch(e){next(e)}};
exports.cableProviders=async(req,res,next)=>{try{res.json({success:true,data:[{name:'DSTV',serviceId:'dstv'},{name:'GOtv',serviceId:'gotv'}]})}catch(e){next(e)}};
exports.cablePackages=async(req,res,next)=>{try{res.json({success:true,data:await prisma.cablePlan.findMany({where:{isActive:true},orderBy:{sellingPrice:'asc'}})})}catch(e){next(e)}};
exports.electricityProviders=async(req,res,next)=>{try{res.json({success:true,data:await prisma.electricityPlan.findMany({where:{isActive:true},orderBy:{name:'asc'}})})}catch(e){next(e)}};
