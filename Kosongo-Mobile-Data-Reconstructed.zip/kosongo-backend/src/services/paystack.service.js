const axios = require('axios');
const { env } = require('../config/env');

async function initializeTransaction({ email, amountNaira, reference, callbackUrl }) {
  const amount = Math.round(Number(amountNaira) * 100);
  if (!Number.isFinite(amount) || amount < 10000) throw new Error('Minimum funding amount is ₦100');
  const response = await axios.post(
    'https://api.paystack.co/transaction/initialize',
    { email, amount, reference, callback_url: callbackUrl },
    { headers: { Authorization: `Bearer ${env.PAYSTACK_SECRET_KEY}`, 'Content-Type': 'application/json' }, timeout: 30000 }
  );
  return response.data;
}
module.exports = { initializeTransaction };
