require('dotenv').config();

const env = process.env;
const required = [
  'DATABASE_URL',
  'JWT_SECRET',
  'PAYSTACK_SECRET_KEY',
  'PAYSTACK_PUBLIC_KEY',
  'VT_PASS_API_KEY',
  'VT_PASS_SECRET_KEY',
  'VT_PASS_BASE_URL'
];

for (const key of required) {
  if (!env[key]) console.warn(`Missing env: ${key}`);
}

module.exports = { ...env, env };
