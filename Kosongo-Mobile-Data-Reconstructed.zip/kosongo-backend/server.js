require('dotenv').config();
const app=require('./src/app');
const {prisma}=require('./src/config/database');
const port=process.env.PORT||5000;
const server=app.listen(port,'0.0.0.0',()=>console.log(`Kosongo backend listening on ${port}`));
for(const sig of ['SIGTERM','SIGINT']) process.on(sig,async()=>{await prisma.$disconnect();server.close(()=>process.exit(0));});
