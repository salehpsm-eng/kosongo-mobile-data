const crypto = require('crypto');
const prisma = require('../config/database');
const { initializeTransaction } = require('../services/paystack.service');

exports.balance = async (req, res, next) => {
  try {
    const wallet = await prisma.wallet.findUnique({ where: { userId: req.user.id } });
    res.json({ success: true, data: wallet || { balance: 0 } });
  } catch (e) { next(e); }
};

exports.transactions = async (req, res, next) => {
  try {
    const rows = await prisma.walletLedger.findMany({ where: { userId: req.user.id }, orderBy: { createdAt: 'desc' }, take: 100 });
    res.json({ success: true, data: rows });
  } catch (e) { next(e); }
};

exports.fund = async (req, res, next) => {
  try {
    const amount = Number(req.body.amount);
    const email = req.user.email;
    if (!Number.isFinite(amount) || amount < 100 || amount > 1000000) {
      return res.status(400).json({ success: false, message: 'Funding amount must be between ₦100 and ₦1,000,000' });
    }
    const reference = `KMD-${Date.now()}-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
    const payment = await prisma.payment.create({
      data: { userId: req.user.id, reference, amount, gateway: 'PAYSTACK', status: 'PENDING' }
    });
    const result = await initializeTransaction({ email, amountNaira: amount, reference });
    if (!result.status) throw new Error(result.message || 'Unable to initialize payment');
    res.status(201).json({ success: true, data: { reference, authorizationUrl: result.data.authorization_url, accessCode: result.data.access_code } });
  } catch (e) { next(e); }
};
